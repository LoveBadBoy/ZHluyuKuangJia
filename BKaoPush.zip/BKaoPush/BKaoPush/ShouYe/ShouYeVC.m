//
//  ShouYeVC.m
//  KaoPushB
//
//  Created by Jincang Lu on 2016/10/18.
//  Copyright © 2016年 shanghai kaoPush. All rights reserved.
//

#import "ShouYeVC.h"

#import "KPBangZhuViewController.h"

@interface ShouYeVC ()

@end

@implementation ShouYeVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self prepareBarButton];
}


- (void)leftBarButtonItemAction
{
    NSLog(@"进入易销接口");
}

-(void)rightBarButtonItemAction
{
    NSLog(@"营业状态改变");
}



//修改一下基类的  navBar  状态
- (void) prepareBarButton{
    
    [self setMyTitle:@"靠铺商家版"];
    [self createLeftBarButtonItem];
    [self createRightBarButtonItem:RightItemTypeTxt text:@"营业中"];
    
    CGSize size =[KPTool stringCGSize:@"进入" font:13 width:0 height:44];
    self.leftButton.frame =CGRectMake(0, 0, size.width, 44);
    self.leftButton.titleLabel.numberOfLines =0;
    self.leftButton.titleLabel.font =[UIFont systemFontOfSize:13];
    [self.leftButton setTitle:@"进入易销" forState:UIControlStateNormal];
    
    self.rightButton.layer.cornerRadius =5;
    self.rightButton.clipsToBounds =YES;
    self.rightButton.layer.borderWidth =1;
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"headNav"] forBarMetrics:UIBarMetricsDefault];
    self.navigationController.navigationBar.translucent = YES;
    
    KPTabbar *tabbar =[KPTabbar shareTabBarController];
    tabbar.tabBar.hidden =NO;
    

}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
