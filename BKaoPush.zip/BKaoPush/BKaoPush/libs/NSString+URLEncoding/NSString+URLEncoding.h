//  SyncGET
//
//  Created by 黎跃春 on 14-10-7.
//  Copyright (c) 2014年 黎跃春. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (URLEncoding)


-(NSString *)URLEncodedString;
-(NSString *)URLDecodedString;


@end
