//
//  ViewController.h
//  BKaoPush
//
//  Created by Jincang Lu on 2016/10/18.
//  Copyright © 2016年 shanghai kaoPush. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

