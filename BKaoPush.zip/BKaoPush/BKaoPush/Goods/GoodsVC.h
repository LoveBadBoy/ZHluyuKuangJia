//
//  GoodsVC.h
//  KaoPushB
//
//  Created by Jincang Lu on 2016/10/18.
//  Copyright © 2016年 shanghai kaoPush. All rights reserved.
//

#import "KPBaseVC.h"

@interface GoodsVC : KPBaseVC

@end
