//
//  KPPersonView.m
//  BKaoPush
//
//  Created by LY on 16/10/20.
//  Copyright © 2016年 shanghai kaoPush. All rights reserved.
//

#import "KPPersonView.h"

@implementation KPPersonView

-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        [self createUI];
    }
    
    return self;
}


-(void)createUI
{
  
    
    UIView *bgView1 =[[UIView alloc] init];
    bgView1.backgroundColor = [UIColor whiteColor];
    [self addSubview:bgView1];
    
    // 图片;
    
    UIImageView *titleIMV = [[UIImageView alloc] initWithFrame:CGRectMake(12, 12, ScreenWidth*0.29, ScreenWidth*0.29)];
    titleIMV.image = [UIImage imageNamed:@"ceshi2.jpeg"];
    [bgView1 addSubview:titleIMV];
    
    //标题
    
    UILabel *titlelab =[[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(titleIMV.frame)+12, 12, ScreenWidth-12-24-ViewWidth(titleIMV), 25)];
    titlelab.text = @"数据 数据";
    [bgView1 addSubview:titlelab];
    
    //经销商 姓名
    
    UILabel *jinglab =[[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(titleIMV.frame)+12, CGRectGetMaxY(titlelab.frame)-5, 100, 25)];
    jinglab.text = @"经销商: 猴赛雷";
    jinglab.font =SS_FONT;
    [bgView1 addSubview:jinglab];
    
    
    UILabel *lianxilab =[[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(titleIMV.frame)+12, CGRectGetMaxY(jinglab.frame)-8, ScreenWidth-12-24-ViewWidth(titleIMV), 25)];
    lianxilab.text = @"联系电话: 15888888888";
    lianxilab.font =SS_FONT;
   
    [bgView1 addSubview:lianxilab];
    
    //地址
    
    CGSize size5 =[KPTool stringCGSize:@"联系地址：中江路879弄天地软件园25号3层" font:S_FONT width:ScreenWidth-24-ViewWidth(titleIMV)-12 height:0];
    UILabel *dizhilab =[[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(titleIMV.frame)+12, CGRectGetMaxY(lianxilab.frame), ScreenWidth-24-ViewWidth(titleIMV)-12, size5.height)];
    dizhilab.numberOfLines =0;
    dizhilab.text = @"联系地址：中江路879弄天地软件园25号3层";
    dizhilab.font =SS_FONT;
    
    bgView1.frame =CGRectMake(0, 0, ScreenWidth, 24+ViewHeight(titlelab)+ViewHeight(jinglab)+ViewHeight(lianxilab)+ViewHeight(dizhilab));
    [bgView1 addSubview:dizhilab];
 
 
    
    CGSize size =[KPTool stringCGSize:@"修改资料" font:S_FONT width:0 height:20];
    UIButton * changeZiLiao =[UIButton buttonWithType:UIButtonTypeCustom];
    [changeZiLiao setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    changeZiLiao.frame =CGRectMake(ScreenWidth-12-8-5-size.width, 12, size.width, 20);
    [changeZiLiao setTitle:@"修改资料" forState:UIControlStateNormal];
    changeZiLiao.tag =1278;
    [changeZiLiao addTarget:self action:@selector(AAchangeZiLiao:) forControlEvents:UIControlEventTouchUpInside];
    changeZiLiao.titleLabel.font =SS_FONT;
    
    [changeZiLiao setEnlargeEdgeWithTop:0 right:20 bottom:0 left:0];
    
    [bgView1 addSubview:changeZiLiao];
    
    
    UIImageView *btnIMA = [[UIImageView alloc] initWithFrame:CGRectMake(CGRectGetMaxX(changeZiLiao.frame)+1, 16, 8, 12)];
    btnIMA.image = [UIImage imageNamed:@"前进.png"];
    [bgView1 addSubview:btnIMA];
 
    UIView *lineView1 =[[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(bgView1.frame), ScreenWidth, 12)];
    lineView1.backgroundColor = [UIColor colorWithWhite:0.94 alpha:1];
    
    [self addSubview:lineView1];
    
    //我的资金
    CGSize zijin1 = [KPTool stringCGSize:@"我的资金" font:15 width:0 height:0];
    UIView *bgview2 =[[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(lineView1.frame), ScreenWidth,zijin1.height+36)];
    bgview2.backgroundColor = [UIColor whiteColor];
    //我的资金
    
    UILabel *zijin =[[UILabel alloc] initWithFrame:CGRectMake(12, 18, zijin1.width, zijin1.height)];
    zijin.text = @"我的资金";
    zijin.font =MM_FONT;
    [bgview2 addSubview:zijin];
    //查看全部 资金按钮
    UIButton *quanbubtn =[[UIButton alloc] initWithFrame:CGRectMake(ScreenWidth-84, 18, zijin1.width, zijin1.height)];
    
    [quanbubtn setTitle:@"查看全部" forState:UIControlStateNormal];
    quanbubtn.titleLabel.font = SS_FONT;
    quanbubtn.tag =1279;
    [quanbubtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [quanbubtn addTarget:self action:@selector(AAquanbuaction:) forControlEvents:UIControlEventTouchUpInside];
    
    [bgview2 addSubview:quanbubtn];
    
    [self addSubview:bgview2];
    
    UIView *lineView2 =[[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(bgview2.frame), ScreenWidth, 2)];
    lineView2.backgroundColor = [UIColor colorWithWhite:0.94 alpha:1];
    [self addSubview:lineView2];
    
    
    UIView *BGview3 = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(lineView2.frame)+2, ScreenWidth, 100)];
    BGview3.backgroundColor = [UIColor whiteColor];
    
    NSArray *arr1 =@[@"总余额",@"可提现资金",@"可用资金",@"未结算资金"];
    for (int i=0; i<4; i++) {
        
        
        UILabel * label1 = [[UILabel alloc] initWithFrame:CGRectMake(ScreenWidth/4.0*0.1+ScreenWidth/4.0*0.9*i, 12, ScreenWidth/4.0*0.9, 40)];
        label1.text = @"15000.00";
        label1.textAlignment = NSTextAlignmentCenter;
        label1.font = SS_FONT;
        [BGview3 addSubview:label1];
        
        
        
        UILabel * label2 = [[UILabel alloc] initWithFrame:CGRectMake(ScreenWidth/4.0*0.1+ScreenWidth/4.0*0.9*i, CGRectGetMaxY(label1.frame)-10, ScreenWidth/4.0*0.9, 40)];
        label2.text = arr1[i];
        label2.textAlignment = NSTextAlignmentCenter;
        label2.font = SS_FONT;
        [BGview3 addSubview:label2];
        
        
    }
    UIView *lineview3 = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(BGview3.frame), ScreenWidth, 12)];
    lineview3.backgroundColor = [UIColor colorWithWhite:0.94 alpha:1];
    
    [self addSubview:lineview3];
    
    UIView *bgview4 = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(lineview3.frame)+12, ScreenWidth, 500)];
    
    bgview4.backgroundColor = [UIColor whiteColor];
    bgview4.userInteractionEnabled=YES;
    NSArray * arr3 = @[@"配送管理",@"营业规格",@"店铺公告",@"分享推广",@"信用评价",@"账号管理",@"我的会员",@"资金明细",@"店铺详情资料",@"帮助中心",@"嘿嘿嘿",@"哈哈哈"];
    for (int i=0; i<arr3.count; i++) {
        UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(15+((ScreenWidth-120)/4.0+30)*(i%4), 15+((ScreenWidth-120)/4.0+50)*(i/4), (ScreenWidth-120)/4.0, (ScreenWidth-120)/4.0);
        button.tag = 1177+i;
        button.backgroundColor = [UIColor redColor];
        [button addTarget:self action:@selector(AAbuttonClick:) forControlEvents:UIControlEventTouchUpInside];
        [bgview4 addSubview:button];
        
        UILabel * label = [[UILabel alloc] initWithFrame:CGRectMake(ScreenWidth/4.0*(i%4),CGRectGetMaxY(button.frame) , ScreenWidth/4.0, 40)];
        label.text = arr3[i];
        //  label.textColor =[UIColor grayColor];
        label.textAlignment = NSTextAlignmentCenter;
        label.font = SS_FONT;
        [bgview4 addSubview:label];
        

    }
    
    
    [self addSubview:BGview3];
    [self addSubview:bgview4];
    
    
    
    self.frame =CGRectMake(0, 0, ScreenWidth,ScreenHeight);
    
}
-(void)AAbuttonClick:(UIButton *)button
{
   
    [self.delegates  KPPersonbuttonClick:button];
}

-(void)AAquanbuaction:(UIButton *)button
{
     [self.delegates  KPPersonbuttonClick:button];

}

- (void)AAchangeZiLiao:(UIButton *) button{

     [self.delegates  KPPersonbuttonClick:button];
   
}



/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
