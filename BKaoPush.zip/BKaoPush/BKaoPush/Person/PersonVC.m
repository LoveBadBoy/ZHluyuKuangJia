//
//  PersonVC.m
//  KaoPushB
//
//  Created by Jincang Lu on 2016/10/18.
//  Copyright © 2016年 shanghai kaoPush. All rights reserved.
//

#import "PersonVC.h"
#import "KPDistributionViewController.h"
#import "KPYingYeViewController.h"
#import "KPFenXiangViewController.h"
#import "KPDianPuViewController.h"
#import "KPXinYongViewController.h"
#import "KPZhangHaoViewController.h"
#import "KPPersonView.h"
#import "KPWoDeViewController.h"
#import "KPZiJinViewController.h"
#import "KPDianPuxiangqingViewController.h"
#import "KPBangZhuViewController.h"



@interface PersonVC ()<UIScrollViewDelegate,KPPersonViewDelegate>
{

    NSMutableArray *datasoucre;
    UIScrollView   *shouyeScroollview;
    KPPersonView   *personView;

}

@end

@implementation PersonVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
   // self.view.backgroundColor = [UIColor colorWithWhite:0.95 alpha:1];
    
    [self prepareBarButton];
    [self createUI];
}

- (void)leftBarButtonItemAction
{
    NSLog(@"进入易销接口");
}


-(void)rightBarButtonItemAction
{
    NSLog(@"营业状态改变");
}


//修改一下基类的  navBar  状态
- (void) prepareBarButton{
    
    [self setMyTitle:@"个人中心"];
    [self createLeftBarButtonItem];
    [self createRightBarButtonItem:RightItemTypeTxt text:@"营业中"];
    
    CGSize size =[KPTool stringCGSize:@"进入" font:13 width:0 height:44];
    self.leftButton.frame =CGRectMake(0, 0, size.width, 44);
    self.leftButton.titleLabel.numberOfLines =0;
    self.leftButton.titleLabel.font =[UIFont systemFontOfSize:13];
    [self.leftButton setTitle:@"进入易销" forState:UIControlStateNormal];
    
    self.rightButton.layer.cornerRadius =5;
    self.rightButton.clipsToBounds =YES;
    self.rightButton.layer.borderWidth =1;
    

    
    
}

- (void) createUI
{

    [self createRootTableView:NO];
    
    
     KPPersonView * kpView = [[KPPersonView alloc] init];
    kpView.delegates =self;
    self.rootTableView.tableHeaderView =kpView;
    
    self.rootTableView.separatorStyle = UITableViewCellSeparatorStyleNone;

    
}

- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 5;
}

#pragma make 按钮响应集合
-(void)KPPersonbuttonClick:(UIButton *)button
{
    
   
    switch (button.tag) {

        case 1177:
        {
            
            KPDistributionViewController *dis = [[KPDistributionViewController alloc] init];
            [self.navigationController pushViewController:dis animated:YES];
        
        
        }
            break;
        case 1178:
        {
            KPYingYeViewController *yingye = [[KPYingYeViewController alloc] init];
            [self.navigationController pushViewController:yingye animated:YES];
            
            
        }
            break;
        case 1179:
        {
            KPDianPuViewController *dianpu =[[KPDianPuViewController alloc] init];
            [self.navigationController pushViewController:dianpu animated:YES];
            
            
        }
            break;
        case 1180:
        {
            KPFenXiangViewController *fenxiang = [[KPFenXiangViewController alloc]init];
               [self.navigationController pushViewController:fenxiang animated:YES];
            
        }
            break;
        case 1181:
        {
            KPXinYongViewController *xinyong =[[KPXinYongViewController alloc] init];
            [self.navigationController pushViewController:xinyong animated:YES];
            
        }
            break;
        case 1182:
        {
            KPZhangHaoViewController *zhanghao =[[KPZhangHaoViewController alloc] init];
            [self.navigationController pushViewController:zhanghao animated:YES];
            
            
        }
            break;
        case 1183:
        {
            KPWoDeViewController *wode =[[KPWoDeViewController alloc] init];
            [self.navigationController pushViewController:wode animated:YES];
            
            
        }
            break;
        case 1184:
        {
          KPZiJinViewController   *zijin =[[KPZiJinViewController alloc] init];
            [self.navigationController pushViewController:zijin animated:YES];
            
        }
            break;
        case 1185:
        {
            KPDianPuxiangqingViewController   *xiangqing =[[KPDianPuxiangqingViewController alloc] init];
            [self.navigationController pushViewController:xiangqing animated:YES];
            
        }
            break;
        case 1186:
        {
            KPBangZhuViewController   *bangzhu =[[KPBangZhuViewController alloc] init];
            [self.navigationController pushViewController:bangzhu animated:YES];
            
        }
            break;
        case 1279:
        {
             NSLog(@"这是全部按钮");
            
        }
            break;
        case 1278:
        {
            NSLog(@"这是修改资料");
            
        }
            break;
        default:
            break;
    }
    
}


#pragma make 单机修改资料

//查看全部
#pragma make 查看全部
//-(void)quanbuaction:(UIButton *) button
//{
//    NSLog(@"查看全部在资金 按钮响应");
//
//}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"headNav"] forBarMetrics:UIBarMetricsDefault];
    self.navigationController.navigationBar.translucent = YES;
    
    [KPTabbar shareTabBarController].tabBar.hidden =NO;
    
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
