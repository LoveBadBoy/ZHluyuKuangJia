//
//  KPZhangHaoViewController.h
//  BKaoPush
//
//  Created by LY on 16/10/20.
//  Copyright © 2016年 shanghai kaoPush. All rights reserved.
//

#import "KPBaseVC.h"

@interface KPZhangHaoViewController : KPBaseVC

@end
